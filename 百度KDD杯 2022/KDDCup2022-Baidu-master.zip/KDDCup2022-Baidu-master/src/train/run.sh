# 07091

python nn_train.py --seed 3150
