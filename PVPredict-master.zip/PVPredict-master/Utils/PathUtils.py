root_data_path = "C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/OriginData/"
test1_path = "C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/OriginData/test_1.csv"
test2_path = "C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/OriginData/test_2.csv"
test3_path = "C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/OriginData/test_3.csv"
test4_path = "C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/OriginData/test_4.csv"

train1_path = "C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/OriginData/train_1.csv"
train2_path = "C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/OriginData/train_2.csv"
train3_path = "C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/OriginData/train_3.csv"
train4_path = "C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/OriginData/train_4.csv"


proceed_data_path ="C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/processed_data/"

train_and_test_rootpath = "C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/processed_data/"
predict_rootpath = "C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/predict/"
feature_importance_rootpath ="C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/feature_importance/"
map_rootpath ="C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/MapData/"

modelMergeData_path = "C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/modelMergeData/"
modelData_path = "C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/model/"

modelPredict_path = "C:/Users/Tobin/PycharmProjects/PhotovoltaicPower/model1Predict/"
